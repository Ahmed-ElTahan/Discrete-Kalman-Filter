clc; clear all; close all;

%% Define Parameters
n = 2;                 % number of states
m = 1;                % number of measurements
K_final =  42;    % number of iterations 
t = 1:K_final;     % iteration vector

phi = [1 1; 0 1]; % State transition matrix
B = [-0.5; -1];    % Input-Control vector
g = 9.8;             % gravity
H = [1 0];          % measurements - output vector
In = eye(n);
Im = eye(m);
q = 100;            % Variance of the the system disturbance output
r = 200000;       % Variance of the the system measurements output
v = random('Normal', 0, sqrt(r), m,K_final);    % disturbance noise
w = random('Normal', 0, sqrt(q), n,K_final);   % measurements noise

R = v*v'*Im;        % Measurement noise covariance matrix
Q = w*w'*In;       % Process noise covariance matrix

w = mat2cell(w, [n], [ones(1,K_final)]); 
v = mat2cell(v, [m], [ones(1,K_final)]);

xhat_p = cell(1, K_final);          % posterior estimate of x_k
xhat_m = cell(1, K_final);         % prior estimate of x_k
z = cell(1, K_final);                    % measurments 
x_pure = cell(1,K_final);           % process output without noise
x = cell(1,K_final);                     % variable used to collect measurements

% Initialization
xhat_m{1}(1,1) = 9000;
xhat_m{1}(2,1) = 0;
x_pure{1}(1,1) = 10000;
x_pure{1}(2,1) = 0;
x{1}(1,1) = 10000;
x{1}(2,1) = 0;
z{1} = H*xhat_m{1}+v{1};

K = cell(1, K_final);
P_m = cell(1, K_final);
P_p = cell(1, K_final);
alpha = 1e6;
P_m{1} = alpha*eye(n, n);

%% Collecting Measurements with Process Disturbance
for k = 1 : K_final-1
    x_pure{k+1} = phi*x_pure{k}+B*(g);
    x{k+1} = phi*x{k}+B*(g)+w{k};
    z{k+1} = H*x{k} + v{k};
end

%% Kalman Algorithm
for k = 1 : K_final
    K{k} = P_m{k}*H'*inv(H*P_m{k}*H'+R);
    xhat_p{k} = xhat_m{k}+K{k}*(z{k}-H*xhat_m{k});
    P_p{k} = (In - K{k}*H)*P_m{k};
    P_m{k+1} = phi*P_p{k}*phi'+Q;
    xhat_m{k+1} = phi*xhat_p{k}+B*(g);
end

%% Extracting Data
State1 = cell2mat(x_pure);
pos1 = State1(1,:);
vel1 = State1(2,:);
State2 = cell2mat(xhat_m);
pos2 = State2(1,1:end-1);
vel2 = State2(2,1:end-1);
measure = cell2mat(z);
measure = measure(1,:);
State3 = cell2mat(xhat_p);
pos3 = State3(1,:);
vel3 = State3(2,:);

%% Plotting
hh = figure;
hold all
plot(t, pos1 ,'LineWidth', 2, 'color', 'black')
plot(t, pos2, 'LineWidth', 2, 'color', 'blue')
plot(t, measure, '--*', 'LineWidth', 2, 'color', 'red')
plot(t, pos3, '--', 'LineWidth', 2, 'color', 'blue')
xlabel('time')
ylabel('Height h')
xlim([0 K_final])
grid on
legend('Height without disturbance', 'Height with disturbance', 'Height measurement with noise', 'Kalman filtered height')
print(hh, '-dpng', '-r1000', 'pos')
print(hh, '-depsc', 'pos')

hh = figure;
hold all
plot(t, vel1,'LineWidth', 2, 'color', 'black')
plot(t, vel2,'LineWidth', 2, 'color', 'blue')
plot(t, vel3 ,'--','LineWidth', 2, 'color', 'blue')
xlabel('time')
ylabel('Falling rate h^o')
xlim([0 K_final])
grid on
legend('Velocity without disturbance', 'Velocity with disturbance', 'Kalman filter velocity output')
print(hh, '-dpng', '-r1000', 'vel')
print(hh, '-depsc', 'vel')